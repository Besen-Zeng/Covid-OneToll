package android.utils;

public class Place {
    private String xarea;
    private String city;
    private String lat;
    private String lng;

    public String getXarea() {
        return xarea;
    }

    public void setXarea(String xarea) {
        this.xarea = xarea;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }
}
